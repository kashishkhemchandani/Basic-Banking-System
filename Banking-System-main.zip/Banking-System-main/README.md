# Basic_Banking_System
This project is done as a part of The Sparks Foundation Internship  #GRIPMar21

[![email](https://img.shields.io/static/v1.svg?label=Basic_Banking&message=System&color=grey&logo=gmail&style=flat&logoColor=white&colorA=critical)](https://github.com/thedramatickid/bank1) [![outlook](https://img.shields.io/static/v1.svg?label=Outlook&message=Template&color=grey&logo=microsoft-outlook&style=flat&logoColor=white&colorA=dodgerblue)](https://github.com/thedramatickid/bank1)




## Technology Stack Used

![HTML](https://img.shields.io/badge/frontend-html-orange.svg?logo=html5&style=flat-square) 
![CSS](https://img.shields.io/badge/frontend-css-yellowgreen.svg?logo=css3&style=flat-square)
![Mysql](https://img.shields.io/badge/backend-Mysql-pink.svg?logo=Mysql&style=flat-square)
![PHP](https://img.shields.io/badge/backend-PHP-yellow.svg?logo=PHP&style=flat-square)

- Front End - **HTML**, **CSS**
- Back End - **Mysql**, **PHP**
### Still need help?

```

  if (needHelp === true) {
     var emailId = "dhirendra.ksingh@yahoo.com";
     // email is the best way to reach out to me.
     sendEmail(emailId);
  }

```

  [![Instagram](https://img.shields.io/static/v1.svg?label=follow&message=@thedramatickid&color=grey&logo=instagram&style=flat&logoColor=white&colorA=critical)](https://www.instagram.com/thedramatickid/) [![LinkedIn](https://img.shields.io/static/v1.svg?label=connect&message=@dhirendra-singh-115218164/&color=9cf&logo=linkedin&style=flat&logoColor=white&colorA=blue)](https://www.linkedin.com/in/dhirendra-singh-115218164/) [![Twitter](https://img.shields.io/static/v1.svg?label=connect&message=@_thedramatickid&color=grey&logo=twitter&style=flat&logoColor=white&colorA=critical)](https://twitter.com/_thedramatickid)

***Glad to see you here! Show some love by [starring](https://github.com/thedramatickid/Email-Signature/) this repo.***

-----

```

  if (isAwesome) {
    // thanks in advance :p
    starThisRepository();
  }

```

******
