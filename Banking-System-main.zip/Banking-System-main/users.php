<!DOCTYPE HTML>
<!DOCTYPE html>
<html>
<head>
	<title>Success</title>
	<style type="text/css">body{
		margin:0;
	}
</style>
</head>
<body>

	<h2>User does not exists.</h2>

</body>
</html>