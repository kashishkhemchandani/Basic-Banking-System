<HTML>
<head>
	 <meta name="author" content="Vinit Shahdeo">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta name="format-detection" content="telephone=no">
      <link rel="stylesheet" href="style.css">
      <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Caveat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Caveat|Cookie&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Delius&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" crossorigin="anonymous">
	<center><title>Sparks Bank</title></center>
	<link rel = "stylesheet" type = "text/css" href = "buttons.css">
</head>

<body style="background:linear-gradient(to bottom ,black,	#191970,	#000080,#00008B	,#4169E1,blue);background-attachment: fixed;background-repeat: no-repeat;background-size: cover;">
	

<link rel = "stylesheet" type = "text/css" href = "style.css">


	<div class="one" style=" background-color:darkblue;
   height: :50px;
   width:100%;">
		<table width="1330">
            		
			<table width="1200" align="center"  class = "t">
                <tr>
				<td style = "text-align:center"> <button class = "btn1"> Home </button></td> 	
				<td style = "text-align:center"><a href="customer.php" target="frame"><button class = "btn2">View Customers</button></a></td>
				<td style = "text-align:center"><a href="transfermoney.php" target="frame"><button class = "btn2">Transfer Money</button></a></td>
				<td style = "text-align:center"><a href="transactionhistory.php" target="frame"><button class = "btn2">View Transaction History</button></a></td>
                </tr>
            </table>
        </table>
	</div>
	<div class="two">Welcome to</div>
	<h1 >
	
<span style="color: #67E6EC;">T</span>
<span style="color: #67E6EC;">H</span>
<span style="color: #67E6EC;">E</span>
<span style="color: #FF00FF;">S</span>
<span style="color: #FF00FF;">P</span>
<span style="color: #FF00FF;">A</span>
<span style="color: #FF00FF;">R</span>
<span style="color: #FF00FF;">K</span>
<span style="color: #FF00FF;">S</span>
<span style="color: #67E6EC;">B</span>
<span style="color: #67E6EC;">A</span>
<span style="color: #67E6EC;">N</span>
<span style="color: #67E6EC;">K</span>
</h1>
	<div class="three" >This Basic Banking System helps to transfer money between users .<br> It's a simple process , you just need to click on users name and it will automatically jump to next page<br> where you need to select the user to whom you want to transfer money and the amount you want to transfer.<br>
	<div class="four"> Now just click the submit button and YEEEE!!!! YOUR  TRANSACTION  IS  SUCCESSFUL:)</div> 
</div>
<div class="five">Designed By DHIRENDRA || As a part of THE SPARKS FOUNDATION Internship.<br> Have any Query? Feel free to Contact:
</div>

      <span style="color: red; padding: 20px;">

          <br>        
         <a style="margin-left: 600px;color:wheat;" href="https://twitter.com/_thedramatickid" onmouseover="this.style.color='#00FFFF'" onmouseout="this.style.color='white'"><i class="fab fa-twitter fa-2x"></i></a>
         <a style="margin-left: 10px;color:wheat;"href="https://github.com/thedramatickid" onmouseover="this.style.color='#00FFFF'" onmouseout="this.style.color='white'" ><i class="fab fa-github fa-2x"></i></a>
         <a style="margin-left:10px;color:wheat;"href="https://www.linkedin.com/in/dhirendra-singh-115218164//" onmouseover="this.style.color='#00FFFF'" onmouseout="this.style.color='white'"><i class="fab fa-linkedin fa-2x"></i></a>
         <a style="margin-left: 10px;color:wheat;"href="https://www.instagram.com/thedramatickid/" onmouseover="this.style.color='#00FFFF'" onmouseout="this.style.color='white'"><i class="fab fa-instagram fa-2x"></i></a>
         </span> 
         </div>
</body>
</html>